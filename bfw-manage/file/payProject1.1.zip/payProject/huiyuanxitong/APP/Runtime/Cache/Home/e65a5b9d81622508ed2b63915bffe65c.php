<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no" />
    <title></title>
    <link href="/Public/home/wap/css/mui.min.css" rel="stylesheet"/>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/vant@1.6/lib/index.css">

	<style>
		.body{
			line-height: px;
		}
		.mui-table-view-cell:after{
			left: 0px;
			background-color:#292828;
		}
		.mui-table-view:before{
			background-color:#292828;
		}
		.mui-table-view:after{
			background-color:#292828;
		}
	</style>
	<style>
			/*跨webview需要手动指定位置*/
			
			.mui-plus header.mui-bar {
				display: none!important;
			}
			.mui-plus .mui-bar-nav~.mui-content {
				padding:0!important;
			}
			
			.mui-plus .plus{
				display: inline;
			}
			
			.plus{
				display: none;
			}
			
			#topPopover {
				position:fixed;
				top:16px;
				right:6px;
			}
			#topPopover .mui-popover-arrow {
				left:auto;
				right:6px;
			}

			span.mui-icon {
				font-size:14px;
				color:#007aff;
				margin-left:-15px;
				padding-right:10px;
			}
			.mui-popover {
				height:300px;
			}
			.mui-content {
				padding:10px;
			}
			.header{
				background:#1f253d;
				top:0;
				box-shadow:0 0px 0px #ccc;
				-webkit-box-shadow:0 0px 0px #ccc;
			}
			.h1{
				font-family:'微软雅黑';
				color: #fff;
			}
			.ul{
				margin-top:20px;
				background:#1a1d2e;
				line-height:2em;
			}
			.p{
				margin-left:10%;
				font-family:'微软雅黑';
				color:aquamarine;
			}
			.p2{
				position:absolute;
				left:35%;
				bottom:12px;
				font-family:'微软雅黑';
				font-size:1em;
				color: #fff;
			}
			.button{
				display:block;
				position:absolute;
				background:linear-gradient(45deg,BLUE,purple);
				color:#fff;
				top:12px;
				font-size:0.7em;
				right:20px;
				line-height:1.5em;
				width:80px;
				border-radius:8px;
				border:0px solid
				width: 20%;
				height: 25%;
				text-align: center;
				line-height: 230%;
			}

			.buttons{
				display:block;
				position:absolute;
				background:linear-gradient(45deg,BLUE,purple);
				color:#fff;
				top:73px;
				font-size:0.7em;
				right:20px;
				line-height:1.5em;
				width:80px;
				border-radius:8px;
				border:0px solid
				width: 20%;
				height: 25%;
				text-align: center;
				line-height: 230%;
			}

			.buttonss{
				display:block;
				position:absolute;
				background:linear-gradient(45deg,BLUE,purple);
				color:#fff;
				top:113px;
				font-size:0.7em;
				right:20px;
				line-height:1.5em;
		
				border-radius:8px;
				border:0px solid;
				width: 86%;
				height: 25%;
				text-align: center;
				line-height: 230%;
			}
		</style>
</head>
<body style="background: #1a1d2e;">
	<header class="mui-bar mui-bar-nav header">
			<a class="mui-action-back mui-icon mui-icon-left-nav mui-pull-left" href="javascript:history.go(-1)"></a>
			<h1 class="mui-title h1">微信二维码</h1>
		</header>
		<br><br>
		<?php if(empty($wxlist)): else: ?>
		<?php if(is_array($wxlist)): foreach($wxlist as $key=>$info): ?><ul class="mui-table-view ul"  style="margin-top: 48px;">
			<li class="mui-table-view-cell mui-collapse-content"><p class="p">名字</p><p class="p2"><?php echo $info['uname'];?></p> </li>

			<li class="mui-table-view-cell mui-collapse-content"><p class="p">账号</p><p class="p2"><?php echo $info['ewm_acc'];?></p> </li>
			<a type="button" class="button" href="<?php echo U('User/erweimainfo',array('id'=>$info['id']));?>">详情</a>

			<a type="button" class="buttons" href="<?php echo U('User/upma',array('id'=>$info['id']));?>">编辑</a>
            <span id="tys">
			<a type="button" id="xs-<?=$info['id']?>" data-id="<?=$info['id']?>" class="buttonss" href="javascript:">
                <?php  echo $info['zt'] == 1?'已启用，点击切换    ':'<font color="yellow">已停用，点击切换 </font>  '?> &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php  echo $info['zt1'] == 1?'<font color="yellow">收款中</font>':''?>
			</a>
			</span>
		</ul><?php endforeach; endif; endif; ?>
	<script type="text/javascript" src="/Public/home/common/js/jquery-1.9.1.min.js"></script>
	<script type="text/javascript" src="/Public/home/common/layer/layer.js"></script>
	<script type="text/javascript" src="/Public/home/common/js/index.js" ></script>
	<script type="text/javascript" src="/Public/home/common/js/public.js" ></script>
	<script type="text/javascript" src="/Public/home/common/js/common.js" ></script>
	<script type="text/javascript" src="/Public/home/common/js/Uploader.swf" ></script>
	<script type="text/javascript" src="/Public/home/common/js/webuploader.js" ></script>
 <script>
        $('#tys>a').click(function () {
            var id = $(this).attr('data-id');
	        var xs = $(this).attr('id');
            $.ajax({
                url:'/User/tys',
                type:'post',
                data:{'id':id},
                datatype:'json',
                success:function (mes) {

                    if(mes.status == 1){
                        msg_alert(''+mes.msg);
                        $("#"+xs).text(mes.msg);
                    }
                }
            })
        })
    </script>
</body>
</html>