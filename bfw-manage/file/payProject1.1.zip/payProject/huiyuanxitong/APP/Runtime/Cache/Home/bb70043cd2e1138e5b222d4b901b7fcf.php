<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!-- saved from url=(0048)http://103.200.29.54/index.html#tabbar-with-chat -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <title></title>

    <link href="/Public/home/wap/css/mui.min.css" rel="stylesheet">
	<link href="/Public/home/wap/css/app.css" rel="stylesheet">
	<link href="/Public/home/wap/css/qdgame.css" rel="stylesheet">
	<link href="/Public/home/wap/css/1.css" rel="stylesheet">
	<script type="text/javascript" src="/Public/home/common/js/jquery-1.9.1.min.js"></script>
	<script type="text/javascript" src="/Public/home/common/layer/layer.js"></script>
	<script type="text/javascript" src="/Public/home/common/js/index.js" ></script>
	<style>
		
		
	</style>
</head>
<body style="background:#1a1d2e;" class="mui-ios mui-ios-11 mui-ios-11-0">

	<div id="tabbar-with-chat" class="mui-control-content mui-active">
		<header class="mui-bar mui-bar-nav header">
				<h1 class="mui-title h1">抢<?php echo ($sq); ?>单</h1>
		</header>
		<div class="mui-card-content qd">
			<span class="a">最大抢单金额 : </span>
			<span class="b"><?php echo ($max_pipeinone); ?>元</span>
			<span class="c">当前抢单难数 : </span>
			<span class="d"><?php echo ($qd_nd); ?></span>
			<span class="e">接单佣金 : </span>
			<span class="f" style="margin-left: 28%;">微信：<?php echo ($clist['wxb']); ?>%
                        支付宝：<?php echo ($clist['zfbb']); ?>%
                        商家码：<?php echo ($clist['ylb']); ?>%</span>
              
			<button type="button" class="but">冻结金:<?php echo $djs == 0?0:$djs;?>元</button>
		</div>
		<span class="span">【请选择自动抢单类型】</span>
		<ul class="mui-table-view mui-table-view-radio ullei">
			<li class="mui-table-view-cell mui-selected "  id="checkedclass_wx">
				<a class="mui-navigate-right">
					微信
				</a>
			</li>
			<li class="mui-table-view-cell"  id="checkedclass_zfb">
				<a class="mui-navigate-right">
					支付宝
				</a>
			</li>
			<li class="mui-table-view-cell"  id="checkedclass_bank">
				<a class="mui-navigate-right">
					商家码
				</a>
			</li>
		</ul>
		<input type="hidden" name="qdclass" id="qdclass" value="1">
		<input type="hidden" name="qdclass2" id="qdclass2" value="0">
		<input type="hidden" name="qdclass3" id="qdclass3" value="0">

		<?php  if($ulist['zdopention'] == 1){?>	
		<div class="mui-button-row">
			<button type="button" style="    background: linear-gradient(45deg,#009688,#5fb878);" class="mui-btn mui-btn-danger zidong" id="option" onclick="optionqd()">停止自动抢单</button>
		</div>  
		<?php }else{?>
        <div class="mui-button-row">
			<button type="button" style="background:#ccc;color:#000" class="mui-btn mui-btn-danger zidong" id="option" onclick="optionqd()">启用自动抢单</button>
		</div>  

		<?php } ?>


		<div class="mui-button-row">
			<button type="button" class="mui-btn mui-btn-danger zidong" id="autopipei" onclick="zdqd()">开始自动抢单</button>
		</div>   
		<div class="mui-button-row">
	
	</div>
	<span id="zd" style="display: none">1</span>
	<style>



     td{

	 
	    color: #fff;
	    height: 49px;
	    text-align: center;
	}

	th{color: #007aff;}






    </style>
	<span class="span">【手动抢单】</span>
	<div class="mui-card-content qd" style="padding: 3%;height: auto; margin-bottom:100px;">

		

            <table style="width: 100%">
                <tr>
                   <th>类型</th>
                   <th>金额</th>
                   <th>操作</th>
                </tr>
                <tbody id="tpl">
          
                </tbody>
            </table>
			
	</div>
			
<span id="zt">1</span>
<nav class="mui-bar mui-bar-tab" style="background:#1f253d;">
	<a class="mui-tab-item" href="<?php echo U('Index/index');?>">
		<span class="mui-icon mui-icon-home"></span>
		<span class="mui-tab-label">首页</span>
	</a>
	<a class="mui-tab-item mui-active"  href="<?php echo U('Index/qdgame');?>">
		<span class="mui-icon mui-icon-email"></span>
		<span class="mui-tab-label">抢单</span>
	</a>
	
	<a class="mui-tab-item "  href="<?php echo U('Index/shoudan');?>">
		<span class="mui-icon mui-icon-gear"></span>
		<span class="mui-tab-label">收单</span>
	</a>
	<a class="mui-tab-item" href="<?php echo U('User/index');?>">
		<span class="mui-icon mui-icon-contact"></span>
		<span class="mui-tab-label">我的</span>
	</a>
</nav>
</body>

<script type="text/javascript">


	     $(document).ready(function() {
	     	 $.ajax({
                        type: 'POST',
                        url: '<?php echo U("Index/sds");?>',
                        data: '',
                        dataType: 'json',
                        success: function(str) {
                             $("#tpl").empty();
                             $.each(str, function(i, item){      
							
							   html='<tr><td>'+item.t+'</td>';
							   html+= '<td >'+item.price+'</td>';
							   html+= '<td><button type="button" class="mui-btn mui-btn-danger zidong" id="autopipei" onclick="start_sd('+item.id+','+item.class+')" style="    line-height: 1.4em;  margin-top: 7px;">抢单</button></td></tr>';

							   $("#tpl").append(html);
							 });  
                        }
                    });
                var r = window.setInterval(function() {
                    $.ajax({
                        type: 'POST',
                        url: '<?php echo U("Index/sds");?>',
                        data: '',
                        dataType: 'json',
                        success: function(str) {
                             $("#tpl").empty();
                             $.each(str, function(i, item){      
							
							   html='<tr><td>'+item.t+'</td>';
							   html+= '<td >'+item.price+'</td>';
							   html+= '<td><button type="button" class="mui-btn mui-btn-danger zidong" id="autopipei" onclick="start_sd('+item.id+','+item.class+')" style="    line-height: 1.4em;  margin-top: 7px;">抢单</button></td></tr>';

							   $("#tpl").append(html);
							 });  
                        }
                    });

                    if ($("#zt").text()== 1) {

                    	zdqd();
                    }

                    
                },
                3000);
           });




	$('#checkedclass_wx').click(function(){
			$('#checkedclass_wx').addClass("mui-selected");
			$('#checkedclass_zfb').removeClass("mui-selected");
			$('#checkedclass_bank').removeClass("mui-selected");
			$('#qdclass').val(1);
		});
		$('#checkedclass_zfb').click(function(){
			$('#checkedclass_zfb').addClass("mui-selected");
			$('#checkedclass_wx').removeClass("mui-selected");
			$('#checkedclass_bank').removeClass("mui-selected");
			$('#qdclass').val(2);
		});
		$('#checkedclass_bank').click(function(){
			$('#checkedclass_bank').addClass("mui-selected");
			$('#checkedclass_zfb').removeClass("mui-selected");
			$('#checkedclass_wx').removeClass("mui-selected");
			$('#qdclass').val(3);
		});
	
</script>
<script type="text/javascript">

	function zdqd(){

		var qdclass = $('#qdclass').val();
		var qdclass2 = $('#qdclass2').val();
		var qdclass3 = $('#qdclass3').val();

		$.post("<?php echo U('Index/zidong');?>",
			{'qdclass' : qdclass,'qdclass2':qdclass2,'qdclass3':qdclass3},
			function(data){
				if(data.status==1){
					showSound();
					layer.msg(data.msg);  //,data.url);
                    $("#zt").text(0);
					setTimeout(function (args) {
						window.location.href = "<?php echo U('Index/shoudan');?>";
					}, 5000); 
				}
		 });

		
	}

 	function showSound(audioSrc='/Public/home/common/dd.mp3') {
            /**因为音效元素是追加的，所以每次生成之前，将原来的删除掉*/
            $("#hint").remove();
            /**创建audio标签的Jquery对象，然后追加到body进行播放即可*/
            let audioJQ = $("<audio src='" + audioSrc + "' autoplay id='hint'/>");
            audioJQ.appendTo("body");
        }


	function optionqd(){
		$("#option").attr('disabled',true);
		$.post("<?php echo U('Index/qdoption');?>",
			function(data){
				if(data.status == 1){
					layer.msg(data.msgs);  //,data.url);
					$("#option").attr('disabled',false);
					$("#option").text(data.msg);

					if(data.zr == 1){
                       $("#option").attr('style','background:linear-gradient(45deg,#009688,#5fb878);');

                       $("#zd").text(1);

					} else {
						$("#zd").text(0);
                        $("#option").attr('style','background:#ccc; color:#000');
					}
				}
			});
	}

	function start_sd(id,qdclass){
			
			$.post("<?php echo U('Index/sdq');?>",
				{'id' : id,qdclass:qdclass},
				function(data){
					if(data.status==1){
						layer.msg(data.msg);  //,data.url);
						setTimeout(function (args) {
							window.location.href = "<?php echo U('Index/shoudan');?>";
						}, 2000); 
					}else{
						layer.msg(data.msg);
					}
				});
		}

	

	

</script>


</html>