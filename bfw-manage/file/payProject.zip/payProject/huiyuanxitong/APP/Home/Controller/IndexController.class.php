<?php

namespace Home\Controller;

use Think\Controller;

class IndexController extends CommonController
{

    public function index(){
      
		$ulist2 = M('user')->order('zsy desc')->limit(10)->select();
		
		foreach($ulist2 as $k=>&$v){
			$v['username'] = $this->substr_cut($v['username']);
if ($v['zsy'] == '0.00') {
			 unset($ulist2[$k]);
			}
		
		}
		


		
		$userid = session('userid');
		$ulist = M('user')->where(array('userid'=>$userid))->find();
		$dj = M('dj')->where(array('uid'=>$userid))->select();
		//echo M('dj')->getLastSql();  exit;
		$clist = M('system')->where(array('id'=>1))->find();
	

       

		if (!empty($dj)) {

			foreach ($dj as $k => $v) {

				if(($v['addtime']+(15*60))  < time()) {
	                $uss['money'] = $ulist['money'] + $v['money'];
	                M('user')->where(array('userid'=>$userid))->save($uss);//完成
	                M('dj')->where(array('id'=>$v['id']))->delete();
	                $p['status'] = 4;
	                M('userrob')->where(array('ppid'=>$v['ppid']))->save($p);//完成
					 
					 
					 $dfdfas=M('userrob')->where(array('ppid'=>$v['ppid']))->find();//完成
		$ewmzt1['zt1']=0 ;
			//$ewmzt1['gengxintime']=time() ;			
			M('ewm')->where(array('id'=>$dfdfas['idewm']))->save($ewmzt1);
					
				}
			}
			
			
		}
		
		
		
		
		
		
		
		
		
		$num = count($ulist2);
		$this->assign('num',$num);
		$this->assign('ulist',$ulist2);
        $this->display();
    }




	 
public function shouquanjc()
	{
		$_var_1 = $_SERVER['HTTP_HOST'];
		if($_var_1<>"www.ceshi.bendi"){
		if($_var_1<>"localhost"){
		if($_var_1<>"127.0.0.1"){
		preg_match('/[\\w][\\w-]*\\.(?:com\\.cn|com|cn|co|net|org|gov|cc|biz|info|wang|xyz|xin|site|shop|ltd|top|win|online|tech|club|cc|ren|vip|lol|help|date|me|pw|group|link|red|ink|pro|biz|mobi|kim|name|tv)(\\/|$)/isU', $_var_1, $_var_2);
		$_var_3 = rtrim($_var_2[0], '/');
		if($_var_1==$_var_3){
			$_var_1="www.".$_var_3;
		}
	
		$_var_4 = array('cailiaofanabcscbvv', $_var_1);
		sort($_var_4, SORT_STRING);
		$_var_5 = strtoupper(substr(sha1(implode($_var_4)), 4, 32));
		$list = M('system')->where(array('id'=>1))->find();
		if ($list['qd_sq'] != $_var_5) {
			return false;
			//return true;
		}
		}
}
}
		return true;
	}
	
	

	
	
		public function shouquan($fdf)
	{
//$_var_1= trim($_SERVER['HTTP_HOST']);
	//$_var_11 =trim($_SERVER['SERVER_NAME']);
	
		$_var_1 = $fdf;
preg_match('/[\\w][\\w-]*\\.(?:com\\.cn|com|cn|co|net|org|gov|cc|biz|info|wang|xyz|xin|site|shop|ltd|top|win|online|tech|club|cc|ren|vip|lol|help|date|me|pw|group|link|red|ink|pro|biz|mobi|kim|name|tv)(\\/|$)/isU', $_var_1, $_var_2);
		$_var_3 = rtrim($_var_2[0], '/');
		if($_var_1==$_var_3){
			$_var_1="www.".$_var_3;
		}

		$_var_4 = array('cailiaofanabcscbvv', $_var_1);
		sort($_var_4, SORT_STRING);
		$_var_5 = strtoupper(substr(sha1(implode($_var_4)), 4, 32));

		return $_var_5;
	}


	
	public function substr_cut($user_name){
		$strlen     = mb_strlen($user_name, 'utf-8');
		$firstStr     = mb_substr($user_name, 0, 2, 'utf-8');
		$lastStr     = mb_substr($user_name, -2, 2, 'utf-8');
		return $strlen == 2 ? mb_substr($user_name, 0, 1, 'utf-8') . str_repeat('*', mb_strlen($user_name, 'utf-8') - 1) : $firstStr . "**" . $lastStr;
	}
	public function qrs(){

		

		if($_GET){
			$Model = M(); 
			$Model->startTrans();
			$userid = session('userid');
			$ulist = M('user')->where(array('userid'=>$userid))->find();
			$id = trim(I('get.id'));
			$olist = M('userrob')->where(array('id'=>$id))->find();

			$ewmlist = M('ewm')->where(array('uid'=>$userid,'ewm_price'=>$olist['price'],'ewm_class'=>$olist['class'],'zt'=>1))->find();

            if($olist['status']!=2 ){

            	$this->error('未知错误',U('Index/shoudan'));
            }

			$sxf = M('system')->where(array('id'=>1))->find();
			$wx = $sxf['wxb'];
			$zfb = $sxf['zfbb'];
			$yl = $sxf['ylb'];

            $m = $olist['pay_money'];  //确认充值的金额//
			if ($olist['class'] == 1) {
				
			   $yj = ($m*$wx/100);

			   $ms = $m;

			} else if($olist['class'] == 2){

               $yj =  ($m*$zfb/100);

               $ms = $m;

			} else if($olist['class'] == 3){

               $yj = ($m*$yl/100);

               $ms = $m;
			}

			
		   $psaves['status'] = 3;

		   $psaves['finishtime'] =  time();
		   M('userrob')->where(array('id'=>$id))->save($psaves);  //完成
		
		   
		   	$ewmzt1['zt1']=0 ;
			$ewmzt1['gengxintime']=time() ;			
			M('ewm')->where(array('id'=>$olist['idewm']))->save($ewmzt1);
		   
		   
		   
           $pid = $olist['ppid'];
           $psave['uid'] = $userid;
		   $psave['uname'] = $ulist['truename'];
		   $psave['umoney'] = $ulist['money'];
		   $psave['pipeitime'] = time();
		   $psave['status'] = 3;
						
		   $pipei_re = M('roborder')->where(array('id'=>$pid))->save($psave);//完成
//商户余额增加
$shanghu = M('roborder')->where(array('id'=>$pid))->find();//完成
 $shanghuxx = M('agent')->where(array('names'=>$shanghu['shanghu_name']))->find();//完成
 	if ($olist['class'] == 1) {
				
			   $shdz = $m-($m*$shanghuxx['wx']/100);

			 

			} else if($olist['class'] == 2){

               $shdz = $m-($m*$shanghuxx['zfb']/100);

             

			} else if($olist['class'] == 3){

             $shdz = $m-($m*$shanghuxx['sjm']/100);

             
			}
 

 
       $shye['money'] = $shanghuxx['money']+$shdz;
$pipei_re = M('agent')->where(array('names'=>$shanghu['shanghu_name']))->save($shye);//完成



           //总收益  
		   $newss = $ulist['zsy']+$yj;
         
		   $usss['zsy'] = $newss;
           $usss['money'] =$ulist['money']+$yj;
		   M('user')->where(array('userid'=>$userid))->save($usss);//完成
       



           $mxs['uid'] = $userid;
		   $mxs['jl_class'] = 1;
		   $mxs['info'] = '佣金收入+';
		   $mxs['addtime'] = time();
		   $mxs['jc_class'] = '+';
		   $mxs['num'] = $yj;


           $up_re = M('somebill')->add($mxs);

		
		   $mxss['uid'] = $userid;
		   $mxss['jl_class'] = 6;
		   $mxss['info'] = '充值'.$m.'确认-';
		   $mxss['addtime'] = time();
		   $mxss['jc_class'] = '-';
		   $mxss['num'] = $m;


           $up_re = M('somebill')->add($mxss);


           M('dj')->where(array('ppid'=>$pid))->delete();
		   
		   
		   
		   

           //////////////////////////////
           ///
           /// 
           
					$clist = M('system')->where(array('id'=>1))->find();
					$oneuser = M('user')->where(array('userid'=>$ulist['pid']))->find();//上一代
					
					//一代佣金奖励
					if(!empty($oneuser)){
						
						$oneyj_money = $yj * $clist['team_oneyj']; //上一代佣金
						
						$puser_inc_re = M('user')->where(array('userid'=>$ulist['pid']))->setInc('money',$oneyj_money);
						
						if($puser_inc_re){							
							$puser_bill['uid'] = $oneuser['userid'];
							$puser_bill['jl_class'] = 1; //佣金类型
							$puser_bill['info'] = '直推抢单成功佣金'; 
							$puser_bill['addtime'] = time(); 
							$puser_bill['jc_class'] = '+'; 
							$puser_bill['num'] = $oneyj_money;
							M('somebill')->add($puser_bill);
						}
						
						$twouser = M('user')->where(array('userid'=>$oneuser['pid']))->find();//上二代
						
						if(!empty($twouser)){
							
							$twoyj_money = $yj * $clist['team_twoyj']; //二代佣金
							$twouser_inc_re = M('user')->where(array('userid'=>$oneuser['pid']))->setInc('money',$twoyj_money);
							if($twouser_inc_re){
								$twouser_bill['uid'] = $twouser['userid'];
								$twouser_bill['jl_class'] = 1; //佣金类型
								$twouser_bill['info'] = '二代抢单成功佣金'; 
								$twouser_bill['addtime'] = time(); 
								$twouser_bill['jc_class'] = '+'; 
								$twouser_bill['num'] = $twoyj_money;
								M('somebill')->add($twouser_bill);
							}
							
							$threeuser = M('user')->where(array('userid'=>$twouser['pid']))->find();//上三代
							if(!empty($threeuser)){
								$threeyj_money = $yj * $clist['team_threeyj']; //三代佣金
								$threeuser_inc_re =  M('user')->where(array('userid'=>$twouser['pid']))->setInc('money',$threeyj_money);
								
								if($threeuser_inc_re){
									$threeuser_bill['uid'] = $threeuser['userid'];
									$threeuser_bill['jl_class'] = 1; //佣金类型
									$threeuser_bill['info'] = '三代抢单成功佣金'; 
									$threeuser_bill['addtime'] = time(); 
									$threeuser_bill['jc_class'] = '+'; 
									$threeuser_bill['num'] = $threeyj_money;
									M('somebill')->add($threeuser_bill);
								}
								
							}
							
							
						}

						
					}

       
			$Model = M()->commit();
			zhifuchenggongtz($id);
		   $this->success('确认成功', U('Index/qdgame'));
		}



	}
	public function zidong(){


    
		 $class =  $_POST['qdclass'];
		 $class2 = $_POST['qdclass2'];
		 $class3 = $_POST['qdclass3'];

	

		 if ($class == 0) {
		 	$str = 1;
		 }else{
		 	$str = $class;
		 }


		 $userid = session('userid');
		 $ulist = M('user')->where(array('userid'=>$userid))->find();

		 if ($ulist['zdopention'] == 0) {
		 	
		 	exit();
		 }
         $clist = M('system')->where(array('id'=>1))->find();
	
         $money = $ulist['money']-$clist['ed'];
         $orderlist = M('roborder')->where("class = $class and status = 1 and price < ".$money)->order(' id desc')->select();
         // echo M('roborder')->getLastSql(); exit;

         ///////////////////////////////////////////////////////////////////////
        
         $id = trim(I('post.id'));
         $qdclass = trim(I('post.qdclass'));
	     
		




			 if ($clist['ed'] >= $money) {
			 	 return false;
			 }
			if($ulist['rz_st'] != 1){
				$data['status'] = 0;
				$data['msg'] = '请先完善资料';
				$this->ajaxReturn($data);exit;
			}
			if($ulist['tx_status'] != 1){
				$data['status'] = 0;
				$data['msg'] = '您的账号被管理员禁止抢单';
				$this->ajaxReturn($data);exit;
			}
			if($ulist['money'] > 0){
				$max_pipeinone = $ulist['money'] * ($clist['qd_cf']  / 100);
			}else{
				$max_pipeinone = 0;
			}
			
			if($max_pipeinone < $clist['qd_minmoney']){
					return false;
			}

			/****需要添加一个未完成订单限制*******/
			$where['status'] = array('not in','3,4');
			$where['uid'] =$userid;
			$no_count = M('userrob')->where($where)->count();
			if($no_count ){
				$data['status'] = 0;
				$data['msg'] = '您有一条匹配订55单未完成';
				//$this->ajaxReturn($data);exit;
				//return false;
			}
			/********************/
			
			$count_qrnum = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1))->count();
			
			if($qdclass == 1){
				$str = '微信收款二维码';
			}elseif($qdclass== 2){
				$str = '支付宝收款二维码';
			}elseif($qdclass==3){
				$str = '商家码';
			}
			
			
			if($count_qrnum < 1){
				$data['status'] = 0;
				$data['msg'] = '您没有上传'.$str.'   或者全部停用了，请至少开启一个';
				return false;
			}
			
				$count_qrnumww = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1,'zt1'=>0))->count();
			
				if($count_qrnumww < 1){
				$data['status'] = 0;
				$data['msg'] = '您开启的'.$str.'都处于收款状态，一个二维码只允许同时收取一单！';
				$this->ajaxReturn($data);exit;
			}
			$keyongppewm = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1,'zt1'=>0))->order('gengxintime')->find();
			
			/*********这里需要区分直接匹配成功，和后台没有发布订单时的排队匹配两种情况********/
			
			
			if(!empty($orderlist)){//后台有符合条件的待匹配订单，生成一条直接匹配好的记录。
				
				if(1){
					
					foreach($orderlist as $k=>$v) {


		                   
					
							if($v['status'] == 1){
								
								$psave['uid'] = $userid;
							$psave['uname'] = $ulist['username'];
								$psave['umoney'] = $ulist['money'];
								$psave['pipeitime'] = time();
								$psave['status'] = 2;
								$id = $v['id'];
								$psave['idewm']=$keyongppewm['id'] ;
								$pipei_re = M('roborder')->where(array('id'=>$id))->save($psave);
					 
						
						
						$ewmzt1['zt1']=1 ;
						
						 M('ewm')->where(array('id'=>$keyongppewm['id']))->save($ewmzt1);
						
					 
							
								
								
								
								
								
								
								if($pipei_re){
									$updata['idewm']=$keyongppewm['id'] ;
								
									$updata['uid'] = $userid;
									$updata['class'] = $qdclass;
									$updata['price'] = $v['price'];
									$updata['yjjc'] = $clist['qd_yjjc'];
									$updata['umoney'] = $ulist['money'];
									$updata['uaccount'] = $ulist['account'];
								 $updata['uname'] = $ulist['username'];
									$updata['ppid'] = $id;
									$updata['status'] = 2;
									$updata['addtime'] = time();
									$updata['pipeitime'] = time();
									$updata['ordernum'] = getordernum();
									$updata['pay_sn'] = $v['ordernum'];;
									$updata['pay_money'] = $v['price'];

									/****************************************************************/
									//$dj = M('dj')->where(array('uid'=>$userid))->find();

									$dj['addtime'] = time();
									$dj['uid'] = $userid;
									$dj['money'] = $v['price'];
									$dj['ppid'] = $id;
		                            M('dj')->add($dj);

		                            $uss['money'] = $ulist['money'] - $v['price'];

		 							M('user')->where(array('userid'=>$userid))->save($uss);//完成
							       /*****************************************************************/
									
									$up_re = M('userrob')->add($updata);
									if($up_re){
										$data['status'] = 1;
										$data['msg'] = '自动匹配成功';

										$this->ajaxReturn($data);exit;
									}
								}
						     }
				  }
				}
			}
		
         ////////////////////////////////////////////////////////////////////////
	}
	
	public function qdgame169(){


 $wz = trim(I('get.sq'));
					//$wz = $this->_get('sq', 'trim');
		if($wz<>""){
		$shouquan=$this->shouquan($wz);
	echo $shouquan;
die;
		}
	}
	
	
	
	public function qdgame(){
 

 $wz = trim(I('get.sq'));
					//$wz = $this->_get('sq', 'trim');
		if($wz<>""){
		$shouquan=$this->shouquan($wz);
		$this->assign('sq', $shouquan);
		}
		$userid = session('userid');
		$ulist = M('user')->where(array('userid'=>$userid))->find();
		$dj = M('dj')->where(array('uid'=>$userid))->select();
		//echo M('dj')->getLastSql();  exit;
		$clist = M('system')->where(array('id'=>1))->find();
		if($ulist['money'] > 0){
			$max_pipeinone = $ulist['money'] * ($clist['qd_cf']  / 100);
		}else{
			$max_pipeinone = 0;
		}

       

		if (!empty($dj)) {

			foreach ($dj as $k => $v) {

				if(($v['addtime']+(15*60))  < time()) {
	                $uss['money'] = $ulist['money'] + $v['money'];
	                M('user')->where(array('userid'=>$userid))->save($uss);//完成
	                M('dj')->where(array('id'=>$v['id']))->delete();
	                $p['status'] = 4;
	                M('userrob')->where(array('ppid'=>$v['ppid']))->save($p);//完成
					
					 $dfdfas=M('userrob')->where(array('ppid'=>$v['ppid']))->find();//完成
								$ewmzt1['zt1']=0 ;
			//$ewmzt1['gengxintime']=time() ;			
			M('ewm')->where(array('id'=>$dfdfas['idewm']))->save($ewmzt1);
				}
			}
			
			
		}
		

		
		$tarr = explode(',',$clist['qd_ndtime']);
		$djs = M('dj')->where(array('uid'=>$userid))->sum('money');
		
		/******只能手动后台更改了*****/
		$clist = M('system')->where(array('id'=>1))->find();
		$this->assign('clist',$clist);
		$this->assign('tarr',$tarr);
		$this->assign('qd_nd',$clist['qd_nd']);
		$this->assign('qd_yjjc',$clist['qd_yjjc']);
		$this->assign('djs',$djs);
		$this->assign('max_pipeinone',$max_pipeinone);
		$this->assign('ulist',$ulist);
		$this->display();		
	}

	public function shoudan(){
		$userid = session('userid');
		$slist = M('userrob')->where(array('uid'=>$userid,'status'=>2))->order('id desc')->select();
		$flist = M('userrob')->where(array('uid'=>$userid,'status'=>3))->order('id desc')->select();
		$dlist = M('userrob')->where(array('uid'=>$userid,'status'=>4))->order('id desc')->select();
		$this->assign('slist',$slist);
		$this->assign('flist',$flist);
		$this->assign('dlist',$dlist);
		
		
		
		
		$this->display();	
	}
	
	//会员抢单详请
	public function qiangdanxq(){
		if($_GET){
			
			$userid = session('userid');
			$ulist = M('user')->where(array('userid'=>$userid))->find();
			$id = trim(I('get.id'));
			$olist = M('userrob')->where(array('id'=>$id))->find();
			//$ewmlist = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$olist['class'],'zt'=>1))->find();
			$ewmlist = M('ewm')->where(array('id'=>$olist['idewm']))->find();
			$this->assign('olist',$olist);
			$this->assign('ewmlist',$ewmlist);
			$this->display();
			
		}else{
			$this->error('未知错误',U('Index/shoudan'));
		}
		
	}
	public function qdoption(){

		if(1){
			$uid = session('userid');
			$ulist = M('user')->where(array('userid'=>$uid))->find();
		
			

            if ($ulist['zdopention'] == 1) {
                $sava['zdopention'] = 0;
                $msgs = '自动抢单已关闭';
                $msg = '启用自动抢单';
                $zr = 0;
            } else {
            	$msg = '停止自动抢单';
            	$msgs = '自动抢单已开启';
            	$sava['zdopention'] = 1;
            	$zr = 1;
            }
			


			$re = M('user')->where(array('userid'=>$uid))->save($sava);
			if($re){
				$data['status'] = 1;
				$data['msg'] = $msg;
				$data['msgs'] = $msgs;
				$data['zr'] = $zr;
				$this->ajaxReturn($data);exit;
			}else{
				$data['status'] = 0;
				$data['msg'] = '设置失败';
				$this->ajaxReturn($data);exit;
			}
			
		}


	}
	
	//生成抢单订单
	public function pipeiorder(){
		if($_POST){
			exit;
			$qdclass=trim(I('post.qdclass'));

			$qdclass2=trim(I('post.qdclass2'));


			$userid = session('userid');
			$ulist = M('user')->where(array('userid'=>$userid))->find();
			$clist = M('system')->where(array('id'=>1))->find();
			if($ulist['rz_st'] != 1){
				$data['status'] = 0;
				$data['msg'] = '请先完善资料';
				$this->ajaxReturn($data);exit;
			}
			if($ulist['tx_status'] != 1){
				$data['status'] = 0;
				$data['msg'] = '您的账号被管理员禁止抢单';
				$this->ajaxReturn($data);exit;
			}
			if($ulist['money'] > 0){
				$max_pipeinone = $ulist['money'] * ($clist['qd_cf']  / 100);
			}else{
				$max_pipeinone = 0;
			}
			
			if($max_pipeinone < $clist['qd_minmoney']){
				$data['status'] = 0;
				$data['msg'] = '最低抢单额度为'.$clist['qd_minmoney'];
				$this->ajaxReturn($data);exit;
			}

			/****需要添加一个未完成订单限制*******/
			$where['status'] = array('not in','3,4');
			$where['uid'] =$userid;
			$no_count = M('userrob')->where($where)->count();
			if($no_count ){
				$data['status'] = 0;
				$data['msg'] = '您有一条匹配订单未完成';
				$this->ajaxReturn($data);exit;
			}
			/********************/
			
			$count_qrnum = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1))->count();
			
			if($qdclass == 1){
				$str = '微信收款二维码';
			}elseif($qdclass== 2){
				$str = '支付宝收款二维码';
			}elseif($qdclass==3){
				$str = '商家码';
			}
			if($qdclass2 == 1){
				$str = '微信收款二维码';
			}elseif($qdclass2== 2){
				$str = '支付宝收款二维码';
			}elseif($qdclass2==3){
				$str = '商家码';
			}
			
			if($count_qrnum < 1){
				$data['status'] = 0;
				$data['msg'] = '您没有上传'.$str.'或者全部停用，请至少开启一个';
				$this->ajaxReturn($data);exit;
			}
			
			
			/*********这里需要区分直接匹配成功，和后台没有发布订单时的排队匹配两种情况********/
			$orderlist = M('roborder')->where(array('class'=>$qdclass,'status'=>1))->order('price asc')->select();
			
			if(!empty($orderlist)){//后台有符合条件的待匹配订单，生成一条直接匹配好的记录。
				//符合条件的最小额度的记录为$orderlist[0],所以直接匹配最小的这一条，如果最小金额的都不够匹配，同样也生成一条匹配记录，提示等待(不采用)				
				//这里写业务
				//循环匹配收款二维类型及金额都符合则匹配成功
				$ewmlist = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1))->select();
				foreach($orderlist as $k=>$v){
					foreach($ewmlist as $val){
						if($v['price'] == $val['ewm_price']){
							$st = 1;
							$pid = $v['id'];
							break;
						}
					}
				}
				if($st == '' || $st ==0){
					$pipeist = 0;
				}elseif($st == 1){
					$pipeist = 1;
				}
				
				if($pipeist == 1){//匹配成功更新后台发布的订单/生成一条匹配成功的会员匹配记录  同时减去会员账号余额，且加上佣金'qd_yjjc' 生成日录(确认后做这些操作)
					
					
					
					$tolist = M('roborder')->where(array('id'=>$pid))->find();//被匹配的这一条记录
					
					if($tolist['status'] == 1){
						
						$psave['uid'] = $userid;
						$psave['uname'] = $ulist['truename'];
						$psave['umoney'] = $ulist['money'];
						$psave['pipeitime'] = time();
						$psave['status'] = 2;
						
						$pipei_re = M('roborder')->where(array('id'=>$pid))->save($psave);
						
						if($pipei_re){
							
							$updata['uid'] = $userid;
							$updata['class'] = $qdclass;
							$updata['price'] = $tolist['price'] == ''?1000:$tolist['price'];
							$updata['yjjc'] = $clist['qd_yjjc'];
							$updata['umoney'] = $ulist['money'];
							$updata['uaccount'] = $ulist['account'];
							$updata['uname'] = $ulist['truename'];
							$updata['ppid'] = $pid;
							$updata['status'] = 2;
							$updata['class2'] = $qdclass2;
							$updata['addtime'] = time();
							$updata['pipeitime'] = time();
							$updata['ordernum'] = getordernum();
							
							$up_re = M('userrob')->add($updata);
							if($up_re){
								$data['status'] = 1;
								$data['msg'] = '匹配成功';
								$this->ajaxReturn($data);exit;
							}else{
								$data['status'] = 0;
								$data['msg'] = '未知错误';
								$this->ajaxReturn($data);exit;
							}
						}else{
							$data['status'] = 0;
							$data['msg'] = '未知错误';
							$this->ajaxReturn($data);exit;
						}
					}else{
						
						$updata['uid'] = $userid;
						$updata['class'] = $qdclass;
						$updata['price'] = '10000';
						$updata['yjjc'] = '';
						$updata['umoney'] = $ulist['money'];
						$updata['uaccount'] = $ulist['account'];
						$updata['uname'] = $ulist['truename'];
						$updata['ppid'] = '';
						$updata['status'] = 1;
						$updata['addtime'] = time();
						
						$updata['ordernum'] = getordernum();
						$up_re = M('userrob')->add($updata);
						
						if($up_re){
							
							$data['status'] = 1;
							$data['msg'] = '已生成订单等待自动匹配';
							$this->ajaxReturn($data);exit;
						}else{
							
							$data['status'] = 0;
							$data['msg'] = '未知错误';
							$this->ajaxReturn($data);exit;
						}

					}

					
				}else{
					
					
					$erm = M('ewm')->where(array('uid'=>$userid,'zt'=>1,'ewm_price'=>array('elt',$max_pipeinone)))->order('ewm_price asc')->select();
					if(!$erm){
						$data['status'] = 0;
						$data['msg'] = '抢单额度不足';
						//$this->ajaxReturn($data);exit;
					}
					
					$updata['uid'] = $userid;
					$updata['class'] = $qdclass;
					$updata['price'] = '10000';
					$updata['yjjc'] = '';
					$updata['umoney'] = $ulist['money'];
					$updata['uaccount'] = $ulist['account'];
					$updata['uname'] = $ulist['truename'];
					$updata['ppid'] = '';
					$updata['status'] = 1;
					$updata['addtime'] = time();
					$updata['ordernum'] = getordernum();
					$up_re = M('userrob')->add($updata);
					
					if($up_re){
						
						$data['status'] = 1;
						$data['msg'] = '已生成订单等待自动匹配';
						$this->ajaxReturn($data);exit;
					}else{
						
						$data['status'] = 0;
						$data['msg'] = '未知错误';
						$this->ajaxReturn($data);exit;
					}
				}
				
				
			}else{//后台没有符合条件的单则生成一条记录，提示等待
			
				$updata['uid'] = $userid;
				$updata['class'] = $qdclass;
				$updata['price'] = 10000;
				$updata['yjjc'] = '';
				$updata['umoney'] = $ulist['money'];
				$updata['uaccount'] = $ulist['account'];
				$updata['uname'] = $ulist['truename'];
				$updata['ppid'] = '';
				$updata['status'] = 1;
				$updata['addtime'] = time();
				$updata['ordernum'] = getordernum();
				$up_re = M('userrob')->add($updata);
				
				if($up_re){
					
					$data['status'] = 1;
					$data['msg'] = '已生成订单等待自动匹配';
					$this->ajaxReturn($data);exit;
				}else{
					
					$data['status'] = 0;
					$data['msg'] = '未知错误';
					$this->ajaxReturn($data);exit;
				}
				
			}

		}else{
			$data['status'] = 0;
			$data['msg'] = '非法操作';
			$this->ajaxReturn($data);exit;
			
		}
		
		
	}

	public function sds(){
        $data = M('roborder')->where(array('status'=>1))->order(' id desc')->select();


        foreach ($data as $k => $v) {
        
        	
             if ($v['class'] == 1) {
		        $data[$k]['t'] = '微信';
		     }
		     if ($v['class'] == 2) {
		        $data[$k]['t'] = '支付宝';
		     }
		     if ($v['class'] == 3) {
		        $data[$k]['t'] = '银联';
		     }
		    $data[$k]['add'] = date('H:i:s',$v['addtime']);
		    
        	
        }


      
		$this->ajaxReturn($data);exit;
	}
	
	
	public function pipeiauto(){
		if($_POST){
			$data['status'] = 0;
			$data['msg'] = '抢单业务繁忙！';
			$this->ajaxReturn($data);exit;
		}else{
			$data['status'] = 0;
			$data['msg'] = '非法操作';
			$this->ajaxReturn($data);exit;
		}
	}


   public function sdq(){
		if($_POST){
		
            $id = trim(I('post.id'));
            $qdclass = trim(I('post.qdclass'));
			$userid = session('userid');
			$ulist = M('user')->where(array('userid'=>$userid))->find();
			$clist = M('system')->where(array('id'=>1))->find();
			if($ulist['rz_st'] != 1){
				$data['status'] = 0;
				$data['msg'] = '请先完善资料';
				$this->ajaxReturn($data);exit;
			}
			if($ulist['tx_status'] != 1){
				$data['status'] = 0;
				$data['msg'] = '您的账号被管理员禁止抢单';
				$this->ajaxReturn($data);exit;
			}
			if($ulist['money'] > 0){
				$max_pipeinone = $ulist['money'] * ($clist['qd_cf']  / 100);
			}else{
				$max_pipeinone = 0;
			}
			
			if($max_pipeinone < $clist['qd_minmoney']){
				$data['status'] = 0;
				$data['msg'] = '最低抢单额度为'.$clist['qd_minmoney'];
				$this->ajaxReturn($data);exit;
			}

			/****需要添加一个未完成订单限制*******/
			$where['status'] = array('not in','3,4');
			$where['uid'] =$userid;
			$no_count = M('userrob')->where($where)->count();
			if($no_count ){
				$data['status'] = 0;
				$data['msg'] = '您有一条匹配订单未完成';
				//$this->ajaxReturn($data);exit;
			}
			/********************/
			
			$count_qrnum = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1))->count();
			
			
			if($qdclass == 1){

				$str = '微信收款二维码';
			}elseif($qdclass== 2){

				$str = '支付宝收款二维码';

			}elseif($qdclass==3){

				$str = '商家码';
			}
			
			if($count_qrnum < 1){
				$data['status'] = 0;
				$data['msg'] = '您没有上传'.$str.'    或者全部停用了，请开启至少一个';
				$this->ajaxReturn($data);exit;
			}
			
			$count_qrnumww = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1,'zt1'=>0))->count();
			
				if($count_qrnumww < 1){
				$data['status'] = 0;
				$data['msg'] = '您开启的'.$str.'都处于收款状态，一个二维码只允许同时收取一单！';
				$this->ajaxReturn($data);exit;
			}
			$keyongppewm = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1,'zt1'=>0))->order('gengxintime')->find();
			
			
			/*********这里需要区分直接匹配成功，和后台没有发布订单时的排队匹配两种情况********/
			$orderlist = M('roborder')->where(array('id'=>$id))->order('price asc')->select();


 			if ($clist['ed'] >= $ulist['money']) {
			 	$data['status'] = 0;
				$data['msg'] = '保证金预留额度必须大于'.$clist['ed'].'元';
				$this->ajaxReturn($data);exit;
			 }

			if ($orderlist['price'] >= $ulist['money']) {
				$data['status'] = 0;
				$data['msg'] = '您最高抢单额度为'.$ulist['money'];
				$this->ajaxReturn($data);exit;
			}


			
			if(!empty($orderlist)){//后台有符合条件的待匹配订单，生成一条直接匹配好的记录。
				//符合条件的最小额度的记录为$orderlist[0],所以直接匹配最小的这一条，如果最小金额的都不够匹配，同样也生成一条匹配记录，提示等待(不采用)				
				//这里写业务
				//循环匹配收款二维类型及金额都符合则匹配成功
				$ewmlist = M('ewm')->where(array('uid'=>$userid,'ewm_class'=>$qdclass,'zt'=>1))->select();
				
				
				if(1){
					
					
					
					$tolist = M('roborder')->where(array('id'=>$id))->find();//被匹配的这一条记录

					if ($tolist['price'] >= ($ulist['money']-$clist['ed'])) {
						$data['status'] = 0;
						$data['msg'] = '您最高抢单额度为'.($ulist['money']-$clist['ed']);
						$this->ajaxReturn($data);exit;
					}
					
					if($tolist['status'] == 1){
						
						$psave['uid'] = $userid;
						$psave['uname'] = $ulist['username'];
						$psave['umoney'] = $ulist['money'];
						$psave['pipeitime'] = time();
						$psave['status'] = 2;
						$psave['idewm']=$keyongppewm['id'] ;
						
						$pipei_re = M('roborder')->where(array('id'=>$id))->save($psave);
						
						
						$ewmzt1['zt1']=1 ;
						
						 M('ewm')->where(array('id'=>$keyongppewm['id']))->save($ewmzt1);
						
						
						
						if($pipei_re){
							$updata['idewm']=$keyongppewm['id'] ;
							$updata['uid'] = $userid;
							$updata['class'] = $qdclass;
							$updata['price'] = $tolist['price'];
							$updata['yjjc'] = $clist['qd_yjjc'];
							$updata['umoney'] = $ulist['money'];
							$updata['uaccount'] = $ulist['account'];
							$updata['uname'] = $ulist['username'];
							$updata['ppid'] = $id;
							$updata['status'] = 2;
							$updata['addtime'] = time();
							$updata['pipeitime'] = time();
							$updata['ordernum'] = getordernum();
							$updata['pay_sn'] = $tolist['ordernum'];
							$updata['pay_money'] = $tolist['price'];

							/****************************************************************/
							//$dj = M('dj')->where(array('uid'=>$userid))->find();

							/****************************************************************/
									//$dj = M('dj')->where(array('uid'=>$userid))->find();

									$dj['addtime'] = time();
									$dj['uid'] = $userid;
									$dj['money'] = $tolist['price'];
									$dj['ppid'] = $id;
		                            M('dj')->add($dj);

		                            $uss['money'] = $ulist['money'] - $tolist['price'];

		 							M('user')->where(array('userid'=>$userid))->save($uss);//完成
									
									
									
									
							       /*****************************************************************/
							/*****************************************************************/
							
							$up_re = M('userrob')->add($updata);
							if($up_re){
								$data['status'] = 1;
								$data['msg'] = '抢单成功..';
								$this->ajaxReturn($data);exit;
							}else{
								$data['status'] = 0;
								$data['msg'] = '未知错误';
								$this->ajaxReturn($data);exit;
							}
						}else{
							$data['status'] = 0;
							$data['msg'] = '未知错误';
							$this->ajaxReturn($data);exit;
						}
				 }
				
				}
			}

		}else{
			$data['status'] = 0;
			$data['msg'] = '非法操作';
			$this->ajaxReturn($data);exit;
			
		}
		
		
	}


}