<?php

namespace Admin\Model;

use Admin\Model\UserModel;


class ComplaintModel extends UserModel
{
    /**
     * 数据库表名
     * 
     */
    protected $tableName = 'complaint';
}
