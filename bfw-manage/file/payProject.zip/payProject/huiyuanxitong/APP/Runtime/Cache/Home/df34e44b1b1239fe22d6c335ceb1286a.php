<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!-- saved from url=(0038)http://103.200.29.54/index.html#tabbar -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    
    <meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
    <title></title>

    <link href="/Public/home/wap/css/mui.min.css" rel="stylesheet">
	<link href="/Public/home/wap/css/app.css" rel="stylesheet">
	<link href="/Public/home/wap/css/indexindex.css" rel="stylesheet">

	<style>
		.bgcolor10{background: #8A6DE9;}
		.bgcolor9{background:grey;}
		.bgcolor8{background: darkslateblue;}
		.bgcolor7{background: darkgray;}
		.bgcolor6{background: #EC971F;}
		.bgcolor5{background: #007aff;}
		.bgcolor4{background: orange;}
		.bgcolor3{background: burlywood;}
		.bgcolor2{background:  blue;}
		.bgcolor1{background: red;}


	</style>
</head>
<body style="background:#1a1d2e;" class="mui-ios mui-ios-11 mui-ios-11-0">

<a class="mui-tab-item" href="<?php echo U('Login/shm');?>">
				<span class="mui-icon mui-icon-info-filled"></span>
			</a>

</p>
		<div id="tabbar" class="mui-control-content mui-active">
<!-- <span style="position: absolute; bottom: 0; left: 0;top:50px">	<p>
电脑同时打开登录以下页面测试<br/>
1、http://api.moxka.cn/api 商户充值接口页面演示<br/>
在这里模拟商家用户充值 发起充值订单<br/>
2、http://pao.moxka.cn/  跑分用户登录<br/>
用户名：13800138000 密码：123456<br/>
在这里进行自动或者手动抢单 并收款确认<br/>
充值页面自动提示充值成功<br/>
3、http://shanghu.moxka.cn/agent/ 商户查看自己的收入<br/>
4、http://pao.moxka.cn/admin  系统管理员操作<br/>
</p></span>
-->
			<header class="mui-bar mui-bar-nav header">
					<h1 class="mui-title h1">收益排行榜</h1>
			</header>
		
				<img src="../Public/home/wap/images/phbbg.png" class="img">
		
			<div class="mui-card-content">
				<ul class="mui-table-view ul">
					<?php for($i=1;$i<=$num;$i++){?>
		            <li class="mui-table-view-cell mui-collapse mui-collapse-content">
						<span class="phblist">
							<img src="../Public/home/wap/images/logoer.png" style="width: 40px;/">
							<span class="phbacc"><?php echo $ulist[$i-1]['username'];?></span>
							<span class="phbaac"><?php echo $ulist[$i-1]['zsy'];?></span>
						</span>
						<span class="mui-badge mui-badge-primary <?php echo 'bgcolor'.$i;?>"><?php echo $i;?></span>
					</li>
					<?php }?>

		        </ul>
			</div>
		</div>
			

		<nav class="mui-bar mui-bar-tab" style="background:#1f253d;">
			<a class="mui-tab-item mui-active" href="<?php echo U('Index/index');?>">
				<span class="mui-icon mui-icon-home"></span>
				<span class="mui-tab-label">首页</span>
			</a>
			<a class="mui-tab-item" href="<?php echo U('Index/qdgame');?>">
				<span class="mui-icon mui-icon-email"></span>
				<span class="mui-tab-label">抢单</span>
			</a>
			
			<a class="mui-tab-item" href="<?php echo U('Index/shoudan');?>">
				<span class="mui-icon mui-icon-gear"></span>
				<span class="mui-tab-label">收单</span>
			</a>
			<a class="mui-tab-item" href="<?php echo U('User/index');?>">
				<span class="mui-icon mui-icon-contact"></span>
				<span class="mui-tab-label">我的</span>
			</a>
		</nav>
		
</body>
</html>