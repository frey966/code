<?php 

define('ACC',TRUE);

include('../sys/init.php');
if (!$_SESSION['admin_uid']&&!$_SESSION['admin_name']) {
   include('./tpl/login/login.html');exit();
}
$auid = $_SESSION['pp'];
$act = isset($_REQUEST['act'])?$_REQUEST['act']:'list';

$user_total = $mysql->count('ysk_user','pid ='.$_SESSION['admin_uid']);

$resum = $mysql->sum('ysk_recharge','price','status = 3 and uid in (' .$auid. ')');

$wisum = $mysql->sum('ysk_withdraw','price','status = 3 and uid in (' .$auid. ')');


$countmoney = $mysql->sum('ysk_user','money','pid ='.$_SESSION['admin_uid']);

$countmoney = $mysql->sum('ysk_user','money','pid ='.$_SESSION['admin_uid']);
$sumyj = $mysql->sum('ysk_user','zsy','pid ='.$_SESSION['admin_uid']);

$start=strtotime(date('Y-m-d'));
		
$end=$start+86400;
		
$where="  and reg_date BETWEEN {$start} AND {$end} ";

$user_count =  $mysql->count('ysk_user','pid ='.$_SESSION['admin_uid'] . $where);


$finishorder_count = $mysql->count('ysk_userrob',' status = 3 and uid in (' .$auid. ')');


$finishorder_money = $mysql->sum('ysk_userrob','price',' status = 3 and uid in (' .$auid. ')');

$sucorder_count = $mysql->count('ysk_userrob',' status = 2 and uid in (' .$auid. ')');

$sucorder_money = $mysql->sum('ysk_userrob','price',' status = 2 and uid in (' .$auid. ')');

$q = $mysql->sum('ysk_userrob','price',' status = 1 and uid in (' .$auid. ')');



$cg = round(($q/$finishorder_count )*100);



include('./tpl/index/tongji.html');
  




?>