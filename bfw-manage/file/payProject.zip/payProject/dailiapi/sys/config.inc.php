<?php
defined('ACC')||exit('ACC Denied');
$_CFG = array();

$_CFG['host'] = 'localhost';
$_CFG['user'] = 'xgc_im';
$_CFG['pwd'] = 'S4BRsjp6GFA3zY7j';
$_CFG['db'] = 'xgc_im';
$_CFG['char'] = 'utf8';

$_CFG['act'] = $_SERVER['DOCUMENT_ROOT'].'/act/';

$_CFG['tpl'] = $_SERVER['DOCUMENT_ROOT'].'/tpl/';

$_CFG['act_ext'] = '.php';
$_CFG['tpl_ext'] = '.php';